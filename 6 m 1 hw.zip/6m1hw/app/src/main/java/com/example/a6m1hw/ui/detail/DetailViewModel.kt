package com.example.a6m1hw.ui.detail

import androidx.lifecycle.ViewModel

class DetailViewModel : ViewModel() {
}