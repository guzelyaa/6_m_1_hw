package com.example.a6m1hw.model

data class Default(
    var height: Int? = null,
    var url: String? = null,
    var width: Int? = null
)