package com.example.a6m1hw.model

data class Localized(
    var description: String? = null,
    var title: String? = null
)