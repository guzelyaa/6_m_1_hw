package com.example.a6m1hw.model

data class PageInfo(
    var resultsPerPage: Int? = null,
    var totalResults: Int? = null
)