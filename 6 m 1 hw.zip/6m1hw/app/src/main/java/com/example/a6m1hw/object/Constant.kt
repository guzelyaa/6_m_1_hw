package com.example.a6m1hw.`object`

object Constant {
    const val PART = "contentDetails,id,snippet"
    const val CHANNEL_ID = "UCX6OQ3DkcsbYNE6H8uQQuVA"
    const val MAX_RESULTS = "7"
}