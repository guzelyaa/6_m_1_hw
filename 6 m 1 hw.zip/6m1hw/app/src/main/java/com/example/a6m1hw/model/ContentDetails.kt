package com.example.a6m1hw.model

data class ContentDetails(
    var itemCount: Int? = null
)